package com.example.instagramfollowers;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginInfo {

    private String phone_id;
    private String _csrftoken;
    private String username;
    private String guid;
    private String device_id;
    private String password;
    private String login_attempt_count = "0";

    LoginInfo(String Username, String Password, String csrftoken) {
        username = Username;
        password = Password;
        _csrftoken = csrftoken;
        phone_id = InstagramAPI.generateUUID(true);
        guid = InstagramAPI.generateUUID(true);
        device_id = "android-"+genString();
    }

    public String getGuid() {
        return guid;
    }

    public static String genString(){
        String all = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 16; i++){
            int k = (int)(Math.random() * 37);
            sb.append(all.charAt(k));
        }
        return sb.toString();
    }

    public JSONObject toJsonObject() throws JSONException {
        JSONObject obj  = new JSONObject();
        obj.put("phone_id",phone_id);
        obj.put("_csrftoken",_csrftoken);
        obj.put("username",username);
        obj.put("guid",guid);
        obj.put("device_id",device_id);
        obj.put("password",password);
        obj.put("login_attempt_count",login_attempt_count);
        return obj;
    }

}
