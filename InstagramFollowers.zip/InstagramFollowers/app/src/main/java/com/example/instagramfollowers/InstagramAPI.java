package com.example.instagramfollowers;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.CookieStore;
import java.net.HttpCookie;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

interface VolleyCallBack<T> {
    public void onSuccess(T object) throws Exception;

}

public class InstagramAPI {

    private final String API_URL = "https://i.instagram.com/api/v1/";
    private SharedPreferences sp;
    private final String IG_SIG_KEY = "4f8732eb9ba7d1c8e8897a75d6474d4eb3f5279137431b2aafb71fafe2abe178";
    private User user;
    private final static String DEBUG_TAG = "DEBUGTAG";
    CookieStore cookies = Main.getCookieManager().getCookieStore();

    private String csrftoken = null;
    private String ds_user_id = null;
    private String uuid = null;

    InstagramAPI (){
        user = User.fromSharedPreferences();
        Log.d(DEBUG_TAG, cookies.getCookies().toString());
    }

    public boolean isUserLoggedIn(){
        return ds_user_id != null && csrftoken != null && uuid != null;
    }

    public User getUser(){
        return user;
    }

    public void getProfileData() throws Exception {
        JSONObject o = new JSONObject();
        o.put("_uuid", uuid);
        o.put("_uid", ds_user_id);
        o.put("_csrftoken", csrftoken);
        String data = o.toString();
        postJsonObject(API_URL + "accounts/current_user/?edit=true", generateSignature(data), new VolleyCallBack() {
            @Override
            public void onSuccess(Object object) throws Exception {
                String body = (String) object;
                Log.d(DEBUG_TAG, body);
            }
        });
    }

    public static String genString(){
        String all = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 16; i++){
            int k = (int)(Math.random() * 37);
            sb.append(all.charAt(k));
        }
        return sb.toString();
    }

    public void Login(final String username, final String password, final RequestDone callback)  {

        cookies.removeAll();
        String login_uri = API_URL + "si/fetch_headers/?challenge_type=signup&guid=" + generateUUID(false);
        getjsonObject(login_uri,new VolleyCallBack() {
            @Override
            public void onSuccess(Object object) throws Exception {
                JSONObject o = (JSONObject) object;

                final String token = cookies.getCookies().get(0).getValue();
                if(o.getString("status").equals("ok")){
                    final String guid = generateUUID(true);
                    JSONObject obj  = new JSONObject();
                    obj.put("phone_id",generateUUID(true));
                    obj.put("_csrftoken", token);
                    obj.put("username",username);
                    obj.put("guid", guid);
                    obj.put("device_id", "android-"+genString());
                    obj.put("password",password);
                    obj.put("login_attempt_count","0");

                    String loString = obj.toString();

                    Map<String, String> Params = generateSignature(loString);
                    String loginURL = API_URL + "accounts/login/";
                    postJsonObject(loginURL, Params, new VolleyCallBack() {
                        @Override
                        public void onSuccess(Object object) throws Exception {
                            createUser((String) object, token, guid);
                            callback.OnDone("OK");
                        }
                    });

                }
            }
        });
    }

    public void createUser(String response, String token, String guid) throws JSONException {
        JSONObject res = new JSONObject(response);
        JSONObject logged_in_user = res.getJSONObject("logged_in_user");
        User.toSharedPreferences(logged_in_user, token, guid);
    }

    public static String encode(String key, String data) throws Exception {
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secret_key = new SecretKeySpec(key.getBytes("UTF-8"), "HmacSHA256");
        sha256_HMAC.init(secret_key);

        return bytesToHex(sha256_HMAC.doFinal(data.getBytes("UTF-8")));
    }

    private static final char[] HEX_ARRAY = "0123456789abcdef".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }


    public static String generateUUID(boolean Dashed){
        String uuid = UUID.randomUUID().toString();
        if(Dashed){
            return uuid;
        }else {
            return uuid.replace("-","");
        }
    }

    public void follow(String userID) throws Exception {
        JSONObject data = new JSONObject();
        data.put("_uuid", "58577ffc-f396-4b55-b335-44531a2e04b0");
        data.put("_uid", ds_user_id);
        data.put("user_id", userID);
        data.put("_csrftoken",csrftoken);

        Map<String, String> Params = generateSignature(data.toString());
        postJsonObject(API_URL + "friendships/create/" + userID + "/" , Params , new VolleyCallBack() {
            @Override
            public void onSuccess(Object object) throws Exception {
                Log.d(DEBUG_TAG, (String) object);
            }
        });
    }

    public void searchUsers(String query, final RequestDone requestDone){
            String url = API_URL+"users/search/?ig_sig_key_version=4&is_typeahead=true&query="+query;
            getjsonObject(url, new VolleyCallBack() {
                @Override
                public void onSuccess(Object object) throws Exception {
                    JSONObject o = (JSONObject) object;
                    requestDone.OnDone(o.toString());
                }
            });
    }

    public void getUserFollowers(String UserId, final RequestDone callback){
        String url = API_URL+ "friendships/"+UserId + "/followers/";
        getjsonObject(url, new VolleyCallBack() {
            @Override
            public void onSuccess(Object object) throws Exception {
                JSONObject o = (JSONObject) object;
                callback.OnDone(o.getJSONArray("users").toString());
            }
        });
    }


    public void getjsonObject(String url, final VolleyCallBack callBack){
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            callBack.onSuccess(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(DEBUG_TAG, ""+error.networkResponse.statusCode+"");
                    }

                }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("User-Agent", "Instagram 10.26.0 Android (18/4.3; 320dpi; 720x1280; Xiaomi; HM 1SW; armani; qcom; en_US)");

                    return params;
                }
        };
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 2,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(Main.getAppContext()).addToRequestQueue(jsonObjectRequest);
    }

    public void postJsonObject(String url, final Map<String, String> Params , final VolleyCallBack callBack){
        final StringRequest StringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {
                            callBack.onSuccess(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(DEBUG_TAG, new String(error.networkResponse.data));
                    }

                }) {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }
            @Override
            public Map<String, String> getParams() {
                return Params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Connection", "close");
                params.put("Accept", "*/*");
                params.put("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
                params.put("Cookie2", "$Version=1");
                params.put("Accept-Language", "en-US");
                params.put("User-Agent", "Instagram 10.26.0 Android (18/4.3; 320dpi; 720x1280; Xiaomi; HM 1SW; armani; qcom; en_US)");

                return params;
            }
        };
        try {
            Log.w(DEBUG_TAG, StringRequest.getHeaders().toString());
            Log.w(DEBUG_TAG, new String(StringRequest.getBody()));
        } catch (AuthFailureError authFailureError) {
            authFailureError.printStackTrace();
        }
        StringRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 2,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(Main.getAppContext()).addToRequestQueue(StringRequest);
    }

    public Map<String, String> generateSignature(String text) throws Exception {
        String signed_body = encode(IG_SIG_KEY,text);
        signed_body+="."+ text;

        Map<String, String> Params = new HashMap<>();
        Params.put("signed_body",signed_body);
        Params.put("ig_sig_key_version","4");
        return Params;
    }

}
