package com.example.instagramfollowers;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class FollowService extends Service {
    InstagramAPI API;
    JSONArray array;
    int i;


    public FollowService(){

    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        i = 0;
        Log.d(Main.DEBUG_TAG,"Service Started");
        final NotificationManager mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    "Elti3",
                    "Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT);

            serviceChannel.setSound(null,null);
            mNotifyManager.createNotificationChannel(serviceChannel);
        }






        //startForeground(1,notification.build());


        API = new InstagramAPI();
        String jsonArrayString = intent.getStringExtra("jsonArray");
        final int max = intent.getIntExtra("max",0);

        final NotificationCompat.Builder notification = new NotificationCompat.Builder(this,"Elti3")
                .setContentTitle("Following Progress")
                .setContentText("0/"+max)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setProgress(max,0,false)
                .setSound(null);

        mNotifyManager.notify(1, notification.build());

        try {
            Log.d("ELTIONI",jsonArrayString);
            array = new JSONArray(jsonArrayString);
            Log.d("ELTIONI", array.toString());
            final ScheduledExecutorService scheduleTaskExecutor = Executors.newScheduledThreadPool(5);
            scheduleTaskExecutor.scheduleAtFixedRate(new Runnable() {
                public void run() {
                    try {
                        if(i < max) {

                            notification.setProgress(max,i+1,false)
                                        .setContentText((i+1)+"/"+max);
                            mNotifyManager.notify(1,notification.build());
                            API.follow(array.getJSONObject(i).getLong("pk") + "");
                            Intent in= new Intent();
                            in.setAction("service.follow");
                            in.putExtra("username",array.getJSONObject(i).getString("username"));
                            sendBroadcast(in);
                            i++;
                        }else {
                            notification.setProgress(0,0,false)
                                    .setContentText("ALL DONE")
                                    .setDefaults(Notification.DEFAULT_SOUND);
                            mNotifyManager.notify(1,notification.build());
                            scheduleTaskExecutor.shutdownNow();
                            stopSelf();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, 0, 5, TimeUnit.SECONDS);

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
