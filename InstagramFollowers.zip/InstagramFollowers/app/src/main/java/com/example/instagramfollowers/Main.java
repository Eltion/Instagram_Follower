package com.example.instagramfollowers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;

public class Main extends AppCompatActivity {

    private static Context context;
    private static User user;
    InstagramAPI API;
    final static String DEBUG_TAG = "DEBUGTAG";
    private static CookieManager cookieManager;
    private Main.Myreceiver reMyreceive;
    private IntentFilter filter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main2);
        context = getApplicationContext();
        cookieManager = new CookieManager(new PersistentCookieStore(context), CookiePolicy.ACCEPT_ORIGINAL_SERVER);

        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);*/

        filter = new IntentFilter("service.follow");

        CookieHandler.setDefault(cookieManager);
        API = new InstagramAPI();

        if(API.getUser() == null){
            Log.d(DEBUG_TAG, "User not loged");
            Intent Login = new Intent(this, Login.class);
            startActivity(Login);
            return;
        }


        SearchView searchBar = findViewById(R.id.searchBar);
        searchBar.findViewById(android.support.)
        searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                LinearLayout search_result = findViewById(R.id.search_result);
                search_result.removeAllViews();
                if (s.length() > 2)
                    search(s);
                return false;
            }
        });

        User user = API.getUser();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //unregisterReceiver(reMyreceive);
    }
    @Override
    protected void onResume() {
        super.onResume();
        //registerReceiver(reMyreceive, filter);
    }

    public void search(String query){
        final LinearLayout search_result = findViewById(R.id.search_result);
        search_result.removeAllViews();
        API.searchUsers(query, new RequestDone() {
            @Override
            public void OnDone(String response) throws JSONException {
                JSONObject obj = new JSONObject(response);
                JSONArray users = obj.getJSONArray("users");
                for (int i = 0; i < users.length(); i++) {
                    final JSONObject user = users.getJSONObject(i);
                    LinearLayout linearLayout = new LinearLayout(Main.this);
                    linearLayout.setVerticalGravity(Gravity.CENTER);
                    linearLayout.setOrientation(LinearLayout.HORIZONTAL);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
                    linearLayout.setPadding(20,20,20,20);
                    final RoundedImageView img = new RoundedImageView(Main.this);
                    img.setCornerRadius(100);
                    LinearLayout.LayoutParams imgparam = new LinearLayout.LayoutParams(150,150);
                    imgparam.setMargins(20,0,40,0);
                    img.setLayoutParams(imgparam);
                    ImageRequest request = new ImageRequest(user.getString("profile_pic_url"),
                            new Response.Listener<Bitmap>() {
                                @Override
                                public void onResponse(Bitmap bitmap) {
                                    img.setImageBitmap(bitmap);
                                }
                            }, 0, 0, null,
                            new Response.ErrorListener() {
                                public void onErrorResponse(VolleyError error) {

                                }
                            });
                    linearLayout.setBackgroundResource(R.drawable.border);
                    MySingleton.getInstance(Main.this).addToRequestQueue(request);
                    linearLayout.setLayoutParams(lp);
                    TextView txt = new TextView(Main.this);
                    txt.setTextSize(20);
                    txt.setText(user.getString("username"));
                    linearLayout.addView(img);
                    linearLayout.addView(txt);
                    linearLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Log.d(DEBUG_TAG,user.toString());
                            try {
                                getFollowers(user.getLong("pk"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    search_result.addView(linearLayout);
                }
            }
        });
    }

    public void getFollowers(long id){
        final LinearLayout search_result = findViewById(R.id.search_result);
        search_result.removeAllViews();
        API.getUserFollowers(String.valueOf(id), new RequestDone() {
            @Override
            public void OnDone(String response) throws JSONException {
                final JSONArray array = new JSONArray(response);
                GridView gridview = (GridView) findViewById(R.id.gridview);
                gridview.setAdapter(new UserAdapter(Main.this, array));
                //final Button follow = findViewById(R.id.follow);
                /*follow.setEnabled(true);
                follow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent serviceIntent = new Intent(Main.this,FollowService.class);
                        serviceIntent.putExtra("jsonArray",array.toString());
                        int max = Integer.parseInt(((EditText)findViewById(R.id.ToFollow)).getText().toString());
                        serviceIntent.putExtra("max",max);
                        startService(serviceIntent);
                    }
                });*/

            }
        });
    }

    public static CookieManager getCookieManager(){
        return cookieManager;
    }

    public static Context getAppContext() {
        return context;
    }

    public class Myreceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String i = intent.getStringExtra("username");
            Log.d(DEBUG_TAG, i);
            GridView gridView = findViewById(R.id.gridview);
            ((UserAdapter)gridView.getAdapter()).removeChild(0);

        }

    }

}
