package com.example.instagramfollowers;

import org.json.JSONException;

interface RequestDone{
    public void OnDone(String response) throws JSONException;
}