package com.example.instagramfollowers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import org.json.JSONException;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.login);

        Button LoginButton = findViewById(R.id.LoginButton);
        final EditText Username = findViewById(R.id.username1);
        final EditText Password = findViewById(R.id.password);

        final ProgressBar progressBar = findViewById(R.id.progressBar);

        Username.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus)
                    Username.setHint("");
                else
                    Username.setHint("Username");
            }
        });

        Password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus)
                    Password.setHint("");
                else
                    Password.setHint("Password");
            }
        });

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
                String username = Username.getText().toString();
                String pass = Password.getText().toString();
                InstagramAPI api = new InstagramAPI();
                api.Login(username, pass, new RequestDone() {
                    @Override
                    public void OnDone(String response) throws JSONException {
                        Intent i = new Intent(Login.this, Main.class);
                        startActivity(i);
                    }
                });
            }
        });
    }



}
