package com.example.instagramfollowers;

import android.os.Build;
import android.provider.Settings;

import org.json.JSONObject;

public class Device {
    final public String mainfacture = Build.MANUFACTURER;
    final public String model = Build.MODEL;
    final public int android_api = Build.VERSION.SDK_INT;
    final public String android_version = Build.VERSION.RELEASE;
    final public String user_agent = System.getProperty("http.agent");
    final public String android_id =  Settings.Secure.ANDROID_ID;

}
