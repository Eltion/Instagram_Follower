package com.example.instagramfollowers;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class User {
    private String name;
    private String username;
    private String id;
    private String profilePicture;
    private String token;
    private String guid;

    private User(String name, String username, String id, String profilePicture, String token, String guid){
        this.name = name;
        this.username = username;
        this.id = id;
        this.profilePicture = profilePicture;
        this.token = token;
        this.guid = guid;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getId() {
        return id;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public String getGuid() {
        return guid;
    }

    public String getToken() {
        return token;
    }

    public static User fromSharedPreferences(){
        SharedPreferences sp = Main.getAppContext().getSharedPreferences("user",
                Context.MODE_PRIVATE);
        String name = sp.getString("name",null);
        String username = sp.getString("username", null);
        String id = sp.getString("id",null);
        String profilePicture = sp.getString("profilePicture",null);
        String token = sp.getString("token",null);
        String guid = sp.getString("guid",null);
        if(name != null && username != null && id != null && profilePicture != null && token != null && guid != null){
            return new User(name,username,id,profilePicture,token, guid);
        }else {
            return null;
        }
    }

    public static void toSharedPreferences(JSONObject obj,String token, String guid) throws JSONException {
        SharedPreferences.Editor sp = Main.getAppContext().getSharedPreferences("user",
                Context.MODE_PRIVATE).edit();
        sp.putString("name",obj.getString("full_name"));
        sp.putString("username", obj.getString("username"));
        sp.putString("id",String.valueOf(obj.getInt("pk")));
        sp.putString("profilePicture",obj.getString("profile_pic_url"));
        sp.putString("token",token);
        sp.putString("guid",guid);
        sp.apply();
    }
}
