package com.example.instagramfollowers;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.View;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.makeramen.roundedimageview.RoundedImageView;

public class UserView extends RelativeLayout {
    private TextView username;
    private RoundedImageView picture;
    private GridView.LayoutParams param;
    private RelativeLayout.LayoutParams pictureParam;
    private RelativeLayout.LayoutParams usernameParam;
    private Context context;
    public UserView(Context context) {
        super(context);
        this.context = context;
        param = new GridView.LayoutParams(dp(100), LayoutParams.WRAP_CONTENT);
        this.setLayoutParams(param);
        picture = new RoundedImageView(context);
        username = new TextView(context);
        picture.setCornerRadius(300);
        picture.setBorderColor(Color.parseColor("#f37475"));
        picture.setBorderWidth(5f);
        pictureParam = new RelativeLayout.LayoutParams(dp(100),dp(100));
        picture.setLayoutParams(pictureParam);
        picture.setId(ViewIdGenerator.generateViewId());
        pictureParam.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        pictureParam.addRule(RelativeLayout.CENTER_HORIZONTAL);
        usernameParam = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT );
        username.setLayoutParams(usernameParam);
        usernameParam.addRule(RelativeLayout.BELOW, picture.getId());
        usernameParam.addRule(RelativeLayout.CENTER_HORIZONTAL);
        this.addView(picture);
        this.addView(username);
    }

    public void followed(){
        picture.setBorderColor(Color.BLUE);
    }

    public void setPicture(String url){
        ImageRequest request = new ImageRequest(url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        picture.setImageBitmap(bitmap);
                    }
                }, 0, 0, null,
                new Response.ErrorListener() {
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        MySingleton.getInstance(context).addToRequestQueue(request);
    }

    public int dp(int dp){
        return (int) (dp * context.getResources().getDisplayMetrics().density);
    }

    public void setUsername(String username){
        this.username.setText(username);
    }
}
